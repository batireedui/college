<?php
if (isset($_SESSION['user_id'])) {

?>

<?php
}
?>