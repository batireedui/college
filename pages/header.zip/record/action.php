<?php
if (isset($_POST['schooladd'])) {
    $school_name = post('school_name', 300);
    $sum = post('sum', 255);
    $director = post('director', 300);
    $phone = post('phone', 300);
    try {
        $success = _exec(
            "insert into schools (school_name, `sum`, director, phone, tuluv, created_at, updated_at) values (?, ?, ?, ?, ?, ?, ?)",
            'sssssss',
            [$school_name, $sum, $director, $phone, "0", ognoo(), ognoo()],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/school/school");
} else if (isset($_POST['schooledit'])) {
    $id = post('eschool_id', 10);
    $school_name = post('eschool_name', 300);
    $sum = post('esum', 255);
    $director = post('edirector', 300);
    $phone = post('ephone', 300);
    try {
        $success = _exec(
            "UPDATE schools SET school_name=?, `sum`=?, director=?, phone=?, updated_at=? WHERE id=?",
            'sssssi',
            [$school_name, $sum, $director, $phone, ognoo(), $id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/school/school");
} else if (isset($_POST['schooldelete'])) {
    $id = post('dschool_id', 10);
    try {
        $success = _exec(
            "DELETE FROM schools WHERE id=?",
            'i',
            [$id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/school/school");
} else if (isset($_POST['teacherdelete'])) {
    $id = post('teacher_id', 10);
    try {
        $success = _exec(
            "DELETE FROM teachers WHERE id=?",
            'i',
            [$id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/teacher/list");
} else if (isset($_POST['teacheradd'])) {
    $fname = post('fname', 300);
    $lname = post('lname', 300);
    $gender = post('gender', 255);
    $email = post('email', 300);
    $phone = post('phone', 300);
    $rd = post('rd', 20);
    $school = post('school', 10);
    $pass = post('pass', 300);
    try {
        $success = _exec(
            "INSERT INTO teachers(fname, lname, gender, email, phone, rd, school_id, pass, tuluv, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            'ssssssisiss',
            [$fname, $lname, $gender, $email, $phone, $rd, $school, $pass, '0', ognoo(), ognoo()],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/teacher/list");
} else if (isset($_POST['teacheredit'])) {
    $id = post('eteacher_id', 10);
    $fname = post('efname', 300);
    $lname = post('elname', 300);
    $gender = post('egender', 255);
    $email = post('eemail', 300);
    $phone = post('ephone', 300);
    $rd = post('erd', 20);
    $school = post('eschool', 10);
    $pass = post('epass', 300);
    try {
        $success = _exec(
            "UPDATE teachers SET fname=?, lname=?, gender=?, email=?, phone=?, rd=?, school_id=?, pass=?, updated_at=? WHERE id=?",
            'ssssssissi',
            [$fname, $lname, $gender, $email, $phone, $rd, $school, $pass, ognoo(), $id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/teacher/list");
} else if (isset($_POST['najiltandelete'])) {
    $id = post('najiltan_id', 10);
    try {
        $success = _exec(
            "DELETE FROM najiltans WHERE id=?",
            'i',
            [$id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/najiltan/list");
} else if (isset($_POST['najiltanadd'])) {
    $fname = post('fname', 300);
    $lname = post('lname', 300);
    $gender = post('gender', 255);
    $email = post('email', 300);
    $phone = post('phone', 300);
    $rd = post('rd', 20);
    $school = post('school', 10);
    $pass = post('pass', 300);
    try {
        $success = _exec(
            "INSERT INTO najiltans(fname, lname, gender, email, phone, rd, school_id, pass, tuluv, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            'ssssssisiss',
            [$fname, $lname, $gender, $email, $phone, $rd, $school, $pass, '0', ognoo(), ognoo()],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/najiltan/list");
} else if (isset($_POST['najiltanedit'])) {
    $id = post('enajiltan_id', 10);
    $fname = post('efname', 300);
    $lname = post('elname', 300);
    $gender = post('egender', 255);
    $email = post('eemail', 300);
    $phone = post('ephone', 300);
    $rd = post('erd', 20);
    $school = post('eschool', 10);
    $pass = post('epass', 300);
    try {
        $success = _exec(
            "UPDATE najiltans SET fname=?, lname=?, gender=?, email=?, phone=?, rd=?, school_id=?, pass=?, updated_at=? WHERE id=?",
            'ssssssissi',
            [$fname, $lname, $gender, $email, $phone, $rd, $school, $pass, ognoo(), $id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/najiltan/list");
} else if (isset($_POST['angiadd'])) {
    $angi = post('class', 300);
    $buleg = post('buleg', 255);
    $school_id = post('school', 300);
    $teacher_id = post('teacher', 300);
    try {
        $success = _exec(
            "INSERT INTO angis(name, angi, buleg, tuluv, school_id, teacher_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            'sisiiiss',
            ['', $angi, $buleg, '0', $school_id, $teacher_id, ognoo(), ognoo()],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/angilist");
} else if (isset($_POST['angiedit'])) {
    $angi_id = post('eangi_id', 10);
    $angi = post('eclass', 300);
    $buleg = post('ebuleg', 255);
    $school_id = post('eschool', 300);
    $teacher_id = post('eteacher', 300);
    try {
        $success = _exec(
            "UPDATE angis SET name=?, angi=?, buleg=?, tuluv=?, school_id=?, teacher_id=?, updated_at=? WHERE id = ?",
            'sisiiisi',
            ['', $angi, $buleg, '0', $school_id, $teacher_id, ognoo(), $angi_id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/angilist");
} else if (isset($_POST['angidelete'])) {
    $id = post('dangi_id', 10);
    try {
        $success = _exec(
            "DELETE FROM angis WHERE id=?",
            'i',
            [$id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/angilist");
} else if (isset($_POST['studentdelete'])) {
    $id = post('s_id', 10);
    try {
        $success = _exec(
            "DELETE FROM students WHERE id=?",
            'i',
            [$id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/students/list");
} else if (isset($_POST['studentadd'])) {
    $fname = post('ovog', 300);
    $lname = post('ner', 255);
    $gender = post('gender', 300);
    $phone = post('utas', 300);
    $rd = post('rd', 300);
    $school_id = post('school', 300);
    $angi_id = post('class', 300);
    try {
        $success = _exec(
            "INSERT INTO students(fname, lname, gender, phone, rd, school_id, angi_id, created_at, updated_at, tuluv) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            'sssssiissi',
            [$fname, $lname, $gender, $phone, $rd, $school_id, $angi_id, ognoo(), ognoo(), '0'],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/students/list");
} else if (isset($_POST['studentedit'])) {
    $fname = post('eovog', 300);
    $lname = post('ener', 255);
    $gender = post('egender', 300);
    $phone = post('eutas', 300);
    $rd = post('erd', 300);
    $school_id = post('eschool', 10);
    $angi_id = post('eclass', 10);
    $edit_id = post('edit_id', 10);
    try {
        $success = _exec(
            "UPDATE students SET fname=?, lname=?, gender=?, phone=?, rd=?, school_id=?, angi_id=?, updated_at=? WHERE id = ?",
            'sssssiisi',
            [$fname, $lname, $gender, $phone, $rd, $school_id, $angi_id, ognoo(), $edit_id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/students/list");
} else if (isset($_POST['shangilaladd'])) {
    $angilal = post('angilal', 300);
    try {
        $success = _exec(
            "INSERT INTO shalguurbuleg(name, tuluv) VALUES (?, '0')",
            's',
            [$angilal],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/shalguurlist");
} else if (isset($_POST['shangilaledit'])) {
    $angilal = post('eangilal', 300);
    $id = post('eid', 10);
    try {
        $success = _exec(
            "UPDATE shalguurbuleg SET name=? WHERE id=?",
            'si',
            [$angilal, $id],
            $count
        );
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/shalguurlist");
} else if (isset($_POST['bulegdelete'])) {
    $dbuleg_id = post('dbuleg_id', 300);
    try {
        $success = _exec(
            "DELETE FROM shalguurbuleg WHERE id=?",
            'i',
            [$dbuleg_id],
            $count
        );
        $_SESSION['action'] = "Бүлэг устгагдлаа!";
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/shalguurlist");
} else if (isset($_POST['shalguuradd'])) {
    $buleg = $_POST['buleg'];
    $shner = $_POST['shner'];
    $hariult = $_POST['hariult'];
    $expand = 0;
    $tuluv = 0;
    $dedturul = 0;
    if ($_POST['expand'] == "on") {
        $expand = 1;
    }
    if ($_POST['tuluv'] == "on") {
        $tuluv = 1;
    }
    if (isset($_POST['dedturul']) == "on") {
        $dedturul = 1;
    }
    try {
        $success = _exec(
            "INSERT INTO shalguurs(buleg_id, name, ded, turul, tuluv, created_at, updated_at, hariulttype) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            'isiiissi',
            [$buleg, $shner, $expand, $hariult, $tuluv, ognoo(), ognoo(), $dedturul],
            $count
        );
        $_SESSION['action'] = "Бүлэг устгагдлаа!";
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/shalguurlist");
} else if (isset($_POST['shalguuredit'])) {
    $id = $_POST['id'];
    $buleg = $_POST['buleg'];
    $shner = $_POST['shner'];
    $hariult = $_POST['hariult'];
    $expand = 0;
    $tuluv = 0;
    $dedturul = 0;
    if (isset($_POST['expand']) == "on") {
        $expand = 1;
    }
    if (isset($_POST['tuluv']) == "on") {
        $tuluv = 1;
    }
    if (isset($_POST['dedturul']) == "on") {
        $dedturul = 1;
    }
    print_r($_POST);
    
    $success = _exec(
        "UPDATE shalguurs SET buleg_id=?, name=?, ded=?, turul=?, tuluv=?, updated_at=?, hariulttype=? WHERE id = ?",
        'isiiisii',
        [$buleg, $shner, $expand, $hariult, $tuluv, ognoo(), $dedturul, $id],
        $count
    );
    redirect("/shalguurlist");
} else if (isset($_POST['shalguurdelete'])) {
    $dbuleg_id = post('dangi_id', 300);
    try {
        $success = _exec(
            "DELETE FROM shalguurs WHERE id=?",
            'i',
            [$dbuleg_id],
            $count
        );
        $_SESSION['action'] = "Бүлэг устгагдлаа!";
    } catch (Exception $e) {
        $_SESSION['errors'] = ["Системийн алдаа гарлаа. Та дараа дахин оролдоно уу"];
        // echo "Алдаа: " . $e->getMessage() . ' : ' . $e->getFile() . ' : ' . $e->getLine() . ' : Code ' . $e->getCode();
    } finally {
        if (isset($e)) {
            logError($e);
        }
    }
    redirect("/shalguurlist");
}
