<?php require("start.php");
require("header.php");
?>
<!-- / Menu -->
<style>
  .ic {
    font-size: 48px;
  }
</style>
<!-- Layout container -->
<div class="layout-page">
  <!-- Navbar -->
  <?php require("navbar.php");
  ?>
  <!-- / Navbar -->

  <!-- Content wrapper -->
  <div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
      <div class="row">
        <div class="col-lg-12 mb-4 order-0">
          <div class="card">
            <div class="d-flex align-items-end row">
              <div class="col-sm-7">
                <div class="card-body">
                  <h5 class="card-title text-primary">Сайн байн уу! <?= $_SESSION['user_name'] ?>🎉</h5>
                  <?php
                  $sql = "";
                  $sqla = "";
                  if ($user_role != "admin") {
                    $sql = "SELECT school_name FROM schools WHERE id = '$school_id'";
                  }
                  if ($user_role == "teacher") {
                    $sqla = "SELECT concat(angi, buleg) FROM angis WHERE teacher_id = '$user_id' and school_id = '$school_id'";
                  }
                  if ($sql != "") {
                    _selectRowNoParam(
                      $sql,
                      $school_name
                    );
                  }
                  if ($sqla != "") {
                    _selectNoParam(
                      $st,
                      $co,
                      $sqla,
                      $angi_name
                    );
                  }
                  ?>
                  <p class="mb-4">
                    <strong>Хичээлийн жил: <?= $h_jil ?></strong><br>
                    <?php
                    if (isset($school_name)) {
                      echo "Сургууль: " .  $school_name . "<br>";
                    } else {
                      echo "Хэрэглэгчийн төрөл: БШУГ <br>";
                    }
                    if (isset($co) > 0) {
                      while (_fetch($st))
                        echo "Даасан анги: " .  $angi_name . "<br>";
                    }
                    ?>
                  </p>

                  <a href="/account" class="btn btn-sm btn-outline-primary">Хувийн мэдээлэл</a>
                </div>
              </div>
              <div class="col-sm-5 text-center text-sm-left">
                <div class="card-body pb-0 px-0 px-md-4">
                  <img src="/assets/img/illustrations/man-with-laptop-light.png" height="140" alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png" data-app-light-img="illustrations/man-with-laptop-light.png" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row row g-4 mb-4">
        <!-- Order Statistics -->
        <?php if ($user_role == "admin") :
          _selectRowNoParam(
            "SELECT COUNT(id) FROM schools WHERE tuluv=0",
            $school_too
          ); ?>
          <div class="col-sm-6 col-xl-3">
            <div class="card">
              <div class="card-body">
                <div class="d-flex align-items-start justify-content-between">
                  <div class="content-left">
                    <span>Нийт</span>
                    <div class="d-flex align-items-end mt-2">
                      <h1 class="mb-0 me-2"><?= $school_too ?></h1>
                    </div>
                    <small>сургуулийн бүртгэл</small>
                  </div>
                  <span class="badge bg-label-danger rounded p-2">
                    <i class="bx bxs-school bx-lg"></i>
                  </span>
                </div>
              </div>
            </div>
          </div>
        <?php endif ?>
        <?php if ($user_role == "admin") :
          _selectRowNoParam(
            "SELECT COUNT(id) FROM students WHERE tuluv=0",
            $student_too
          ); ?>
          <div class="col-sm-6 col-xl-3">
            <div class="card">
              <div class="card-body">
                <div class="d-flex align-items-start justify-content-between">
                  <div class="content-left">
                    <span>Нийт</span>
                    <div class="d-flex align-items-end mt-2">
                      <h1 class="mb-0 me-2"><?= $student_too ?></h1>
                    </div>
                    <small>сурагчийн бүртгэл</small>
                  </div>
                  <span class="badge bg-label-primary rounded p-2">
                    <i class="bx bxs-graduation bx-lg"></i>
                  </span>
                </div>
              </div>
            </div>
          </div>
        <?php endif ?>
        <?php if ($user_role == "admin") :
          _selectRowNoParam(
            "SELECT COUNT(id) FROM teachers WHERE tuluv=0",
            $basgh_too
          ); ?>
                    <div class="col-sm-6 col-xl-3">
            <div class="card">
              <div class="card-body">
                <div class="d-flex align-items-start justify-content-between">
                  <div class="content-left">
                    <span>Нийт</span>
                    <div class="d-flex align-items-end mt-2">
                      <h1 class="mb-0 me-2"><?= $basgh_too ?></h1>
                    </div>
                    <small>Багшийн бүртгэл</small>
                  </div>
                  <span class="badge bg-label-warning rounded p-2">
                    <i class="bx bxs-group bx-lg"></i>
                  </span>
                </div>
              </div>
            </div>
          </div>
        <?php endif ?>
        <?php if ($user_role == "admin") :
          _selectRowNoParam(
            "SELECT COUNT(id) FROM najiltans WHERE tuluv=0",
            $najiltans_too
          ); ?>
                              <div class="col-sm-6 col-xl-3">
            <div class="card">
              <div class="card-body">
                <div class="d-flex align-items-start justify-content-between">
                  <div class="content-left">
                    <span>Нийт</span>
                    <div class="d-flex align-items-end mt-2">
                      <h1 class="mb-0 me-2"><?= $najiltans_too ?></h1>
                    </div>
                    <small>Нийгмийн ажилтан</small>
                  </div>
                  <span class="badge bg-label-success rounded p-2">
                    <i class="bx bxs-user-voice bx-lg"></i>
                  </span>
                </div>
              </div>
            </div>
          </div>
        <?php endif ?>
      </div>
      <!--/ Order Statistics -->

      <div class="row">
        <div class="col-md-6 col-lg-6 col-xl-6 order-0 mb-4">
          <div class="card">
            <div class="card-body">
              <div id="chart1"></div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-6 col-xl-6 order-0 mb-4">
          <div class="card">
            <div class="card-body">
              <div id="chart2">
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- / Content -->
      <?php if ($user_role == "admin") {
        _selectRowNoParam(
          "SELECT COUNT(id) FROM students WHERE tuluv=0 and gender = 'Эрэгтэй'",
          $men_too
        );
        _selectRowNoParam(
          "SELECT COUNT(students.id) FROM students INNER JOIN angis ON students.angi_id = angis.id WHERE students.tuluv=0 and angis.angi < 6",
          $baga_angi
        );
        _selectRowNoParam(
          "SELECT COUNT(students.id) FROM students INNER JOIN angis ON students.angi_id = angis.id WHERE students.tuluv=0 and angis.angi > 5",
          $ahlah
        );
      } ?>
      <!-- Footer -->
      <?php require "footer.php"; ?>
      <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
      <script>
        chartLoad();

        function chartLoad() {
          var options = {
            series: [<?= $baga_angi ?>, <?= $ahlah ?>],
            labels: ['Бага ангиийн сурагч-<?= $baga_angi ?>', 'Ахлах дунд ангийн сурагч-<?= $student_too - $baga_angi ?>'],
            chart: {
              type: 'donut',
            },
            responsive: [{
              breakpoint: 480,
              options: {
                chart: {
                  width: 200
                },
                legend: {
                  position: 'bottom'
                }
              }
            }],
            title: {
              text: "Сурагчид",
              align: 'center',
              style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: '#263238'
              },
            }
          };
          var options1 = {
            series: [<?= $men_too ?>, <?= $student_too - $men_too ?>, <?= $student_too ?>],
            labels: ['Эрэгтэй-<?= $men_too ?>', 'Эмэгтэй-<?= $student_too - $men_too ?>', 'Нийт-<?= $student_too ?>'],
            chart: {
              type: 'polarArea',
            },
            stroke: {
              colors: ['#fff']
            },
            fill: {
              opacity: 0.8
            },
            responsive: [{
              breakpoint: 480,
              options: {
                chart: {
                  width: 200
                },
                legend: {
                  position: 'bottom'
                }
              }
            }],
            title: {
              text: "Сурагчдын хүйсийн харьцаа",
              align: 'center',
              style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: '#263238'
              },
            }
          };
          var chart = new ApexCharts(document.querySelector("#chart2"), options);
          chart.render();
          var charts = new ApexCharts(document.querySelector("#chart1"), options1);
          charts.render();
        }
      </script>
      <?php require "end.php"; ?>