<?php require("start.php");
require("header.php");
?>
<!-- / Menu -->
<style>
    .ic {
        font-size: 48px;
    }
</style>
<!-- Layout container -->
<div class="layout-page">
    <!-- Navbar -->
    <?php require("navbar.php");
    ?>
    <!-- / Navbar -->

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- User Sidebar -->
            <div class="col-xl-4 col-lg-5 col-md-5 order-1 order-md-0">
                <!-- User Card -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="user-avatar-section">
                            <div class=" d-flex align-items-center flex-column">
                                <div class="user-info text-center">
                                    <h4 class="mb-2"><?=$_SESSION['user_name']?></h4>
                                    <span class="badge bg-label-secondary"><?=$_SESSION['user_role']?></span>
                                </div>
                            </div>
                        </div>
                        <h5 class="pb-2 border-bottom mb-4"></h5>
                        <div class="info-container">
                            <ul class="list-unstyled">
                                <li class="mb-3">
                                    <span class="fw-bold me-2">Эцэг/эх-ийн нэр:</span>
                                    <span>Author</span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-bold me-2">Нэр:</span>
                                    <span>violet.dev</span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-bold me-2">Албан тушаал:</span>
                                    <span class="badge bg-label-success">Active</span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-bold me-2">Утас:</span>
                                    <span>Tax-8965</span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-bold me-2">Email:</span>
                                    <span>vafgot@vultukir.org</span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-bold me-2">Сургууль:</span>
                                    <span>(123) 456-7890</span>
                                </li>
                            </ul>
                            <div class="d-flex justify-content-center pt-3">
                                <a href="javascript:;" class="btn btn-primary me-3" data-bs-target="#editUser" data-bs-toggle="modal">Засварлах</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--/ User Sidebar -->


            <!-- User Content -->
            <div class="col-xl-8 col-lg-7 col-md-7 order-0 order-md-1">
                <div class="card mb-4">
                    <h5 class="card-header">Нууц үг солих</h5>
                    <div class="card-body">
                        <form id="formChangePassword" method="POST" onsubmit="return false" class="fv-plugins-bootstrap5 fv-plugins-framework" novalidate="novalidate">
                            <div class="alert alert-warning" role="alert">
                                <span>Хамгийн багадаа 6-н тэмдэгт оруулна</span>
                            </div>
                            <div class="row">
                                <div class="mb-3 col-12 col-sm-6 form-password-toggle fv-plugins-icon-container">
                                    <label class="form-label" for="newPassword">Шинэ нууц үг</label>
                                    <div class="input-group input-group-merge has-validation">
                                        <input class="form-control" type="password" id="newPassword" name="newPassword" placeholder="············">
                                        <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
                                    </div>
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>

                                <div class="mb-3 col-12 col-sm-6 form-password-toggle fv-plugins-icon-container">
                                    <label class="form-label" for="confirmPassword">Нууц үгээ давтан оруул</label>
                                    <div class="input-group input-group-merge has-validation">
                                        <input class="form-control" type="password" name="confirmPassword" id="confirmPassword" placeholder="············">
                                        <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
                                    </div>
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-primary me-2">Солих</button>
                                </div>
                            </div>
                            <input type="hidden">
                        </form>
                    </div>
                </div>
                <!--/ Change Password -->

                <!-- Recent Devices -->
                <div class="card mb-4">
                    <h5 class="card-header">Таны хандалтын түүх</h5>
                    <div class="table-responsive">
                        <table class="table border-top">
                            <thead>
                                <tr>
                                    <th class="text-truncate">Хэзээ</th>
                                    <th class="text-truncate">IP Хаяг</th>
                                    <th class="text-truncate">Төхөөрөмж</th>
                                </tr>
                            </thead>
                            <tbody><?php
                            _selectNoParam(
                                    $stmt,
                                    $count,
                                    "SELECT device, hezee, ip FROM loginlog WHERE user_role='$user_role' and userid='$user_id'",
                                    $device,
                                    $hezee,
                                    $ip
                                );
                                if($count > 0) :
                                    while (_fetch($stmt)) :
                            ?>
                                <tr>
                                    <td class="text-truncate"><?=$hezee?></td>
                                    <td class="text-truncate"><?=$ip?></td>
                                    <td class="text-truncate"><?=$device?></td>
                                </tr>
                                <?php endwhile ?>
                                <?php endif ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!--/ Recent Devices -->
            </div>
            <!--/ User Content -->
        </div>
    </div>
    <!-- Footer -->
    <?php require "footer.php"; ?>

    <?php require "end.php"; ?>