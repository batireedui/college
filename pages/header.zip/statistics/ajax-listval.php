<?php
if ($_POST["type"] == "valget") {
    //$val[] = array();
    $val = "";
    $pid = $_POST["id"];
    _selectNoParam(
        $sstmt,
        $scount,
        "SELECT COUNT(student_id), (SELECT COUNT(student_id) FROM `sudalgaas` WHERE shalguur_id = '$pid' and value = 1), (SELECT COUNT(student_id) FROM `sudalgaas` WHERE shalguur_id = '$pid' and value = 0) FROM `sudalgaas` WHERE shalguur_id ='$pid'",
        $too,
        $yes,
        $no,
    );
    while (_fetch($sstmt)) {
        //array_push($val, [$too, $yes, $no]);
        $val .= "<button class='btn btn-outline-secondary' style='margin: 10px'>Судалгаа бөглөсөн: $too</button><button class='btn btn-outline-danger' style='margin: 10px' onclick='itemGet($pid, 1)'>Тийм: $yes</button><button class='btn btn-outline-info' style='margin: 10px' onclick='itemGet($pid, 1)'>Үгүй: $no</button>";
    }
    echo $val;
    //echo json_encode($val);
}
if ($_POST["type"] == "itemvalget") {
    //$val[] = array();
    $val = "";
    $pid = $_POST["id"];
    $getval = $_POST["getval"];
    _selectNoParam(
        $sstmt,
        $scount,
        "SELECT COUNT(student_id), shalguur_id, shalguurs.name, value FROM `sudalgaas` INNER JOIN shalguurs ON sudalgaas.shalguur_id = shalguurs.id WHERE student_id IN (SELECT DISTINCT student_id FROM `sudalgaas` WHERE shalguur_id = '$pid' and value = '$getval') GROUP BY shalguur_id",
        $too,
        $yes,
        $no,
    );
    while (_fetch($sstmt)) {
        //array_push($val, [$too, $yes, $no]);
        $val .= "<button class='btn btn-outline-secondary' style='margin: 10px'>Судалгаа бөглөсөн: $too</button><button class='btn btn-outline-danger' style='margin: 10px'>Тийм: $yes</button><button class='btn btn-outline-info' style='margin: 10px'>Үгүй: $no</button>";
    }
    echo $val;
    //echo json_encode($val);
}
