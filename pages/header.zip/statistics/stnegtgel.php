<?php require ROOT . "/pages/start.php"; ?>
<style>
    .rotate {
        padding: .5rem;
        position: relative;
        -webkit-transform: rotate(180deg);
        transform: rotate(180deg);
        white-space: nowrap;
        -webkit-writing-mode: vertical-rl;
        writing-mode: vertical-rl;
    }

    th {
        vertical-align: bottom;
        border: 1px solid #697a8d;
    }

    table td,
    table th {
        border: 1px solid #697a8d;
        padding: .5rem .75rem;
    }
</style>
<?php
require ROOT . "/pages/header.php";

_selectNoParam(
    $stmt,
    $count,
    "SELECT DISTINCT shalguurs.id, shalguurs.name, shalguurs.ded, shalguurs.hariulttype, shalguurs.turul FROM `shalguurs` INNER JOIN activeshes ON shalguurs.id = activeshes.shalguur_id WHERE shalguurs.tuluv = 1 and activeshes.jil = '$h_jil' ORDER BY  shalguurs.id;",
    $shalguur_id,
    $shalguur_name,
    $shalguur_ded,
    $hariulttype,
    $shalguurs_turul
);
$shalguurs = array();
while (_fetch($stmt)) {
    array_push($shalguurs, [$shalguur_id, $shalguur_name, $shalguur_ded, $hariulttype, $shalguurs_turul]);
}
?>

<div class="layout-page">
    <!-- Navbar -->
    <?php require ROOT . "/pages/navbar.php";
    ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card" style="padding: 20px;">
            <div class="row gy-3">
                <!-- Default Modal -->
                <div class="col-lg-6 col-sm-12">
                    <div class="col-sm-6:eq(0)"></div>
                    <h4 class="fw-bold py-3 mb-4">Сургууль</h4>
                </div>
            </div>
            <div id="barChart"></div>
            <div class="table-responsive text-nowrap">
                <table class="table-header-rotated">
                    <thead class="table-light">
                        <tr>
                            <th></th>
                            <?php $d = 0;
                            foreach ($shalguurs as $key => $val) : $d++; ?>
                                <th colspan="2">
                                    <div class="rotate"><?php echo $d . ") " . $val[1] ?></div>
                                </th>
                            <?php endforeach ?>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <tr>
                            <td>Бага анги</td>
                            <?php
                            $too = 0;
                            foreach ($shalguurs as $key => $val) :
                                _selectNoParam(
                                    $istmt,
                                    $icount,
                                    "SELECT COUNT(DISTINCT student_id), sudalgaas.shalguur_id, sudalgaas.value, sudalgaas.shalguurded_id, shalguurs.hariulttype, shalguurs.ded FROM `sudalgaas` INNER JOIN students ON sudalgaas.student_id = students.id INNER JOIN angis ON students.angi_id = angis.id INNER JOIN shalguurs ON sudalgaas.shalguur_id = shalguurs.id INNER JOIN activeshes ON shalguurs.id = activeshes.shalguur_id WHERE sudalgaas.shalguur_id = $val[0] and angis.angi < 6 and activeshes.turul='0' GROUP BY value;",
                                    $val_too,
                                    $val_shid,
                                    $val_value,
                                    $val_ded,
                                    $hariulttype,
                                    $ded
                                );

                                $too++;
                                if ($icount > 0) {
                                    while (_fetch($istmt)) {
                                        if ($ded == 0 && $hariulttype == 1) {
                                            if ($val_value == 1) {
                                                echo "<td colspan='2'>$val_too</td>";
                                            }
                                        } else {
                                            if ($val_value == 1) {
                                                echo "<td>$val_too</td>";
                                            } else echo "<td>$val_too</td>";
                                        }
                                    }
                                } else {
                                    echo "<td colspan='2'> - </td>";
                                }
                            ?>
                            <?php endforeach ?>
                        </tr>
                        <tr>
                            <td>Дунд, ахлах анги</td>
                            <?php
                            $too = 0;
                            foreach ($shalguurs as $key => $val) :
                                _selectNoParam(
                                    $istmt,
                                    $icount,
                                    "SELECT COUNT(DISTINCT student_id), sudalgaas.shalguur_id, sudalgaas.value, sudalgaas.shalguurded_id, shalguurs.hariulttype, shalguurs.ded FROM `sudalgaas` INNER JOIN students ON sudalgaas.student_id = students.id INNER JOIN angis ON students.angi_id = angis.id INNER JOIN shalguurs ON sudalgaas.shalguur_id = shalguurs.id INNER JOIN activeshes ON shalguurs.id = activeshes.shalguur_id WHERE sudalgaas.shalguur_id = $val[0] and angis.angi > 5 and activeshes.turul='1' GROUP BY value;",
                                    $val_too,
                                    $val_shid,
                                    $val_value,
                                    $val_ded,
                                    $hariulttype,
                                    $ded
                                );

                                $too++;
                                if ($icount > 0) {
                                    while (_fetch($istmt)) {
                                        if ($ded == 0 && $hariulttype == 1) {
                                            if ($val_value == 1) {
                                                echo "<td colspan='2'>$val_too</td>";
                                            }
                                        } else {
                                            if ($val_value == 1) {
                                                echo "<td>$val_too</td>";
                                            } else echo "<td>$val_too</td>";
                                        }
                                    }
                                } else {
                                    echo "<td colspan='2'> - </td>";
                                }
                            ?>
                            <?php endforeach ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php require ROOT . "/pages/footer.php"; ?>

        <?php require ROOT . "/pages/end.php"; ?>