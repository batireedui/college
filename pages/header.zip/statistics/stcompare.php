<?php require ROOT . "/pages/start.php"; ?>
<link rel="stylesheet" type="text/css" href="/assets/css/dataTable.css">

<link rel="stylesheet" href="/assets/vendor/libs/select2/select2.css " />
<?php
require ROOT . "/pages/header.php";

_selectNoParam(
    $stmt,
    $count,
    "SELECT DISTINCT shalguurs.id, shalguurs.name, shalguurs.ded, shalguurs.hariulttype, shalguurs.turul FROM `shalguurs` INNER JOIN activeshes ON shalguurs.id = activeshes.shalguur_id WHERE activeshes.jil ='$h_jil'",
    $shalguur_id,
    $shalguur_name,
    $shalguur_ded,
    $shalguur_hariulttype,
    $shalguur_turul
);
?>

<div class="layout-page">
    <!-- Navbar -->
    <?php require ROOT . "/pages/navbar.php";
    ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card" style="padding: 20px;">
            <div class="row gy-3">
                <!-- Default Modal -->
                <div class="col-lg-6 col-sm-12">
                    <div class="col-sm-6:eq(0)"></div>
                    <h4 class="fw-bold py-3 mb-4">Сургууль</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-sm-12">
                    <select id="selectShalg" class="select2 form-control " data-allow-clear="true">
                        <?php
                        while (_fetch($stmt)) {
                            echo "<option value='$shalguur_id'>$shalguur_name</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-lg-6 col-sm-12">
                    <button class="btn btn-outline-primary" onclick="clickShalg()">Харах</button>
                </div>
            </div>
            <div class="row">
                <div id="val">

                </div>
            </div>
        </div>
        <?php require ROOT . "/pages/footer.php"; ?>
        <script src="/assets/vendor/libs/select2/select2.js"></script>
        <script>
            $(document).ready(function() {
                $(".select2").select2();
            });
            function clickShalg(){
                let id = document.getElementById("selectShalg").value;
                console.log(id);
                $.ajax({
                    type: 'POST',
                    url: 'ajax-listval',
                    data: jQuery.param({
                        type: "valget",
                        id: id,
                    }),
                    success: function(data) {
                        $("#val").html(data);
                        console.log(data);
                    }
                });
            }
            function itemGet(id, val){
                $.ajax({
                    type: 'POST',
                    url: 'ajax-listval',
                    data: jQuery.param({
                        type: "itemvalget",
                        id, id,
                        getval: val,
                    }),
                    success: function(data) {
                        $("#val").html(data);
                        console.log(data);
                    }
                });
            }
        </script>
        <?php require ROOT . "/pages/end.php"; ?>